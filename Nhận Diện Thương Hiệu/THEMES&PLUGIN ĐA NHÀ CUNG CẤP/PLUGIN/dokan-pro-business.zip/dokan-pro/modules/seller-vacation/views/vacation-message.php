<div class="dokan-alert dokan-alert-info">
    <p><?php echo esc_html( $message ); ?></p>
</div>
