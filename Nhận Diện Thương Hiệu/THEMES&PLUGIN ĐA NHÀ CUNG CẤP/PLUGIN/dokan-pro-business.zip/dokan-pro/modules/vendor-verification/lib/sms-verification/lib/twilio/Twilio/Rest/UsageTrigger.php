<?php

class Services_Twilio_Rest_UsageTrigger
    extends Services_Twilio_InstanceResource { }

