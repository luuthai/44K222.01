<?php
/*
  Name: Big product card
 */
?>
<?php include(rh_locate_template('inc/ce_common/data_bigcart.php')); ?>