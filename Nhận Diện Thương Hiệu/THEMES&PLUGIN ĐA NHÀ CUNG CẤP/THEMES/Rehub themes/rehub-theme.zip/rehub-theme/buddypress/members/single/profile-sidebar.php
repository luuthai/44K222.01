<?php if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php if ( is_active_sidebar( 'bprh-profile-sidebar' ) ) : ?>
    <?php dynamic_sidebar( 'bprh-profile-sidebar' ); ?>
<?php endif;?>	